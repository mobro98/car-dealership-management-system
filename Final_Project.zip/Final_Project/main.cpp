//
//  main.cpp
//  Car_Dealership_Final_Project
//
//  Created by Mordechai Bronfin on 11/27/17.
//  Copyright © 2017 Mordechai Bronfin. All rights reserved.
//

#include <cstdlib>// For several general-purpose functions
#include <fstream>// For file handling
#include <iomanip>// For formatted output
#include <iostream>// For cin, cout, and system
#include <string>// For string data type
#include <string.h>//getline
#include <istream>//getline
#include <cmath>// for math functions
#include <locale>// for toupper functions
#include <cctype>
#include <vector>
#include <exception>
#include <stdexcept>
#include <typeinfo>

using namespace std;


class car
{
    //base class members, protected, only can be accessed in base and inherited classes. Used to avoid confusion in implementing in main.
protected:
    
    float PRICE;
    int YEAR;
    string VIN;
    string MAKE;
    string CATEGORY;
    string MODEL;
    
public:
    
    string getVin();
    string getModel();
    string getCategory();
    string getMake();
    int getYear();
    float getPrice();
    virtual void printFunction(); //print function
    car(); //defult class constructor
    car(string vin, string make, string model, int year, float price, string category); //constructor with parameters
};

//function definition

string car::getVin()
{
    return VIN;
}

string car::getModel()
{
    return MODEL;
}

string car::getCategory()
{
    return CATEGORY;
}

string car::getMake()
{
    return MAKE;
}

int car::getYear()
{
    return YEAR;
}

float car::getPrice()
{
    return PRICE;
}

void car::printFunction()
{
    cout<<endl<<endl<<"VIN: "<<VIN<<endl<<endl;
    cout<<"Make: "<<MAKE<<endl<<endl;
    cout<<"Model: "<<MODEL<<endl<<endl;
    cout<<"Year: "<<YEAR<<endl<<endl;
    cout<<"Price: "<<PRICE<<endl<<endl;
    cout<<"Category: "<<CATEGORY<<endl<<endl;
}

car::car()
{
    VIN=" ";
    MAKE=" ";
    MODEL=" ";
    CATEGORY=" ";
    YEAR=0;
    PRICE=0;
}

car::car(string vin, string make, string model, int year, float price, string category)
{
    VIN=vin;
    MAKE=make;
    MODEL=model;
    YEAR=year;
    PRICE=price;
    CATEGORY=category;
}

//Declaration of inherited class NewCar

class NewCar : public car
{
    
public:
    NewCar(); //defult constructor
    NewCar(string vin, string make, string model, int year, float price, string category, string warranty); //parametarized constructor
    void printFunction();
    string getWarranty();
    
private:
    string WARRANTY;
};

//NewCar function definition

NewCar::NewCar():car()
{
    WARRANTY=" ";
}

NewCar::NewCar(string vin, string make, string model, int year, float price, string category, string warranty):car(vin, make, model, year, price, category)
{
    WARRANTY=warranty;
}

string NewCar::getWarranty()
{
    return WARRANTY;
}

void NewCar::printFunction()
{
    car::printFunction();
    cout<<"Warranty Provided By: "<<WARRANTY<<endl<<endl;
}

//declaration of second inherited class UsedCar

class UsedCar : public car
{
public:
    UsedCar(); //defult constructor
    UsedCar(string vin, string make, string model, int year, float price, string category, int mileage); //parametarized constructor
    int getMileage();
    void printFunction();
    
private:
    int MILEAGE;
};

//function definitions

int UsedCar::getMileage()
{
    return MILEAGE;
}

void UsedCar::printFunction()
{
    car::printFunction();
    cout<<"Mileage: "<<MILEAGE<<endl<<endl;
}

UsedCar::UsedCar(string vin, string make, string model, int year, float price, string category, int mileage):car(vin, make, model, year, price, category)
{
    MILEAGE=mileage;
}

UsedCar::UsedCar()
{
    MILEAGE=0;
}
//search functions

//search by VIN

bool searchByVIN(string vin, vector<car*> &list)
{
    bool x=false;
    int i;
    
    for(i=0; i<list.size(); i++)
        if((*list[i]).getVin()==vin)
            x=true;
    
    return x;
}

//search by make

bool searchByMake(string make, vector<car*> &list)
{
    bool x=false;
    int i;
    
    for(i=0; i<list.size(); i++)
        
        if((*list[i]).getMake()==make)
        {
            x=true;
            (*list[i]).printFunction();
        }
    
    return x;
}

//search by model

bool searchByModel(string model, vector<car*> &list)
{
    bool x=false;
    int i;
    
    for(i=0; i<list.size();i++)
        if((*list[i]).getModel()==model)
        {
            x=true;
            (*list[i]).printFunction();
        }
    return x;
}

//search by category

bool searchByCategory(string category, vector<car*> &list)
{
    bool x=false;
    int i;
    
    for(i=0; i<list.size();i++)
        if((*list[i]).getCategory()==category)
        {
            x=true;
            (*list[i]).printFunction();
        }
    return x;
}

//menu function

void menu()
{
    cout<<"==================================="<<endl<<endl<<"Car Dealership Management System"<<endl<<endl<<"Press 1 to Search Inventory"<<endl<<endl<<"Press 2 to Sell or Lease a Car"<<endl<<endl<<"Press 3 to Return a Leased Car"<<endl<<endl<<"Press 4 to Add Cars to Inventory"<<endl<<endl<<"Press 5 to Exit the System"<<endl<<endl<<"==================================="<<endl<<endl;
}

//main function

int main()
{
    ifstream file("genLog.txt");
    string MAKE;
    string VIN;
    string CATEGORY;
    string WARRANTY;
    string MODEL;
    float PRICE;
    int YEAR;
    int MILEAGE;
    vector<car*> genLog;
    vector<car*> leaseLog;
    int x, y, choice, searchChoice;
    
    if(file.is_open())
    {
        while(file>>VIN>>YEAR>>MAKE>>MODEL>>CATEGORY>>PRICE)
        {
            
            if(CATEGORY=="NEW")
            {
                file>>WARRANTY;
                
                x=searchByVIN(VIN, genLog);
                if(x==0)
                {
                    genLog.push_back(new NewCar(VIN, MAKE, MODEL, YEAR, PRICE, CATEGORY, WARRANTY));
                }
                else
                {
                    cout<<endl<<"Car exists"<<endl;
                }
            }
            else if(CATEGORY=="USED")
            {
                file>>MILEAGE;
                y=searchByVIN(VIN, genLog);
                if(y==0)
                {
                    genLog.push_back(new UsedCar(VIN, MAKE, MODEL, YEAR, PRICE, CATEGORY, MILEAGE));
                }
                else
                {
                    cout<<endl<<"Car Found!!!!!"<<endl<<endl;
                }
            }
        }
        file.close();
        
}
    
    //infinite loop so menu always appears
    while(1)
    {
        //call menu function
        
        menu();
        cin>>choice;
        switch(choice)
        {
                //search inventory
            case 1:
            {
                cout<<endl<<"Ok, Lets Search Inventory..."<<endl<<endl<<"To Search by Make Press 1"<<endl<<endl<<"To Search by Model Press 2"<<endl<<endl<<"To Search by Category Press 3"<<endl<<endl;
                cin>>searchChoice;
                
                if(searchChoice==1)
                {
                    cout<<endl<<"What is the Make? ";
                    cin>>MAKE;
                    bool c=searchByMake(MAKE, genLog);
                    if(c==false)
                        cout<<endl<<"Not Found :("<<endl<<endl;
                    
                }
                else if(searchChoice==2)
                {
                    cout<<endl<<"What is the Model? ";
                    cin>>MODEL;
                    bool d=searchByModel(MODEL, genLog);
                    if(d==false)
                        cout<<endl<<"Not Found :("<<endl<<endl;
                    
                }
                else if(searchChoice==3)
                {
                    cout<<endl<<"What is the Category? ";
                    cin>>CATEGORY;
                    bool e=searchByCategory(CATEGORY, genLog);
                    if(e==false)
                        cout<<endl<<"Not Found :("<<endl<<endl;
                }
                
                
            }
                break;
                
                //sell or lease cars
            case 2:
            {
                searchChoice=0;
                cout<<endl<<"Ok, Lets Sell/Lease Cars..."<<endl<<endl<<"Press 1 to Sell and 2 to Lease"<<endl<<endl;
                cin>>searchChoice;
                cout<<endl<<"What is the VIN? ";
                cin>>VIN;
                bool g=searchByVIN(VIN, genLog);
                if(g==0)
                    cout<<endl<<"Not Found :("<<endl<<endl;
                else
                {
                    if(searchChoice==1)
                    {
                        for(int m=0; m<genLog.size(); m++)
                            if((*genLog[m]).getVin()==VIN)
                            {
                                genLog.erase(genLog.begin()+m);
                                cout<<endl<<"The Car with VIN "<<VIN<<" was Sold!!!"<<endl<<endl<<"Here is the Inventory Description"<<endl<<endl;
                                for(int l=0; l<genLog.size(); l++)
                                    (*genLog[l]).printFunction();
                                break;
                            }
                    }
                    else if(searchChoice==2)
                    {
                        for(int k=0; k<genLog.size(); k++)
                            if((*genLog[k]).getVin()==VIN)
                            {
                                leaseLog.push_back(genLog[k]);
                                genLog.erase(genLog.begin()+k);
                                cout<<endl<<"The Car with VIN "<<VIN<<" was Leased!!!"<<endl<<endl<<"Here is the  Inventory Description"<<endl<<endl;
                                for(int u=0; u<genLog.size(); u++)
                                    
                                    (*genLog[u]).printFunction();
                                break;
                            }
                        
                    }
                }
                
                
                
            }
                break;
                
                //return leased car by vin
                
            case 3:
            {
                cout<<endl<<"Ok, Lets Return a Leased Car into Inventory"<<endl<<endl<<"What is the VIN? ";
                cin>>VIN;
                bool h=searchByVIN(VIN, leaseLog);
                if(h==false)
                    cout<<endl<<"Not Found :("<<endl<<endl;
                else
                {
                    for(int o=0; 0<leaseLog.size(); o++)
                        if((*leaseLog[o]).getVin()==VIN)
                        {
                            genLog.push_back(leaseLog[o]);
                            leaseLog.erase(leaseLog.begin()+o);
                            cout<<endl<<"The Car Was Returned to Inventory!!!"<<endl<<endl<<"Here is the Car Inventory Description"<<endl<<endl;
                            for(int e=0; e<genLog.size(); e++)
                                (*genLog[e]).printFunction();
                            break;
                        }
                    
                }
            }
                break;
            case 4:
            {
                cout<<endl<<"Ok, Lets add a Car to the Inventory..."<<endl<<endl<<"What is the VIN? ";
                cin>>VIN;
                cout<<endl<<"What Year is it? ";
                cin>>YEAR;
                cout<<endl<<"What is the Make? ";
                cin>>MAKE;
                cout<<endl<<"What is the Model? ";
                cin>>MODEL;
                cout<<endl<<"What is the Price? ";
                cin>>PRICE;
                cout<<endl<<"What is the Category? ";
                cin>>CATEGORY;
                if(CATEGORY=="new"||CATEGORY=="New")
                {
                    cout<<endl<<"Warranty Provider? ";
                    cin>>WARRANTY;
                    int v=searchByVIN(VIN, genLog);
                    if(v==0)
                        genLog.push_back(new NewCar(VIN, MAKE, MODEL, YEAR, PRICE, CATEGORY, WARRANTY));
                    else
                        cout<<endl<<"Car Alread Exists in Inventory, Try Again"<<endl<<endl;
                }
                else if(CATEGORY=="used"||CATEGORY=="Used")
                {
                    cout<<endl<<"What is the Mileage? ";
                    cin>>MILEAGE;
                    int q=searchByVIN(VIN, genLog);
                    if(q==0)
                        genLog.push_back(new UsedCar(VIN, MAKE, MODEL, YEAR, PRICE, CATEGORY, MILEAGE));
                    else
                        cout<<endl<<"Car Alread Exists in Inventory, Try Again"<<endl<<endl;
                }
              cout<<endl<<"Car Was Added to Inventory"<<endl<<endl<<"Here is the Car Inventory Description";
                for(int z=0; z<genLog.size(); z++)
                {
                    (*genLog[z]).printFunction();
                }
                
            }
                break;
                //exit system
            case 5:
            {
                cout<<endl<<"Exiting System..."<<endl<<endl;
                exit(0);
            }
                
                //error handling, prompts user to enter right choice when non-existant choice entered
                
            default:
                cout<<endl<<"Invalid Choice, Try Again"<<endl<<endl<<"Press 1 to Search Inventory"<<endl<<endl<<"Press 2 to Sell or Lease a Car"<<endl<<endl<<"Press 3 to Return a Leased Car"<<endl<<endl<<"Press 4 to Add Cars to Inventory"<<endl<<endl<<"Press 5 to Exit the System"<<endl<<endl;
                
        }
        
    }
    return 0;
}


